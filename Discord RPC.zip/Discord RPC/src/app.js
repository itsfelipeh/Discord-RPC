const clientId = '1227231467592220704';
const DiscordRPC = require('discord-rpc');
const RPC = new DiscordRPC.Client({ transport: 'ipc' });

DiscordRPC.register(clientId);

async function setActivity() {
    if (!RPC) return;
    RPC.setActivity({
        details: 'BTC tho the MoOooN!! 🚀🌕',
        state: ' Trade Crypto on Binance ₿',
        startTimestamp: Date.now(),
        largeImageKey: 'binancebull',
        largeImageTexT: 'bull',
        smallImageKey: 'logo',
        smallImageText: 'binance',
        instance: false,
        buttons: [
            {
                label: 'Don BTC',
                url:'https://link.donbtc.com'
            },
            {
                label: 'Binance',
                url:'https://accounts.binance.com/es-LA/register?ref=25088553'
            }
        ]
    });
};
RPC.on('ready', async () => {
    setActivity();
    setInterval(() => {
        setActivity();
    }, 15 * 1000);

});
RPC.login({ clientId }).catch(err => console.error(err));